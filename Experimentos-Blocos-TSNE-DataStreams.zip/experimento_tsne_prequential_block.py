from itertools import islice
from parametric_tsne import ParametricTSNE
from river import drift
from river import synth
from river import ensemble, linear_model
from river import metrics, evaluate, datasets, tree, preprocessing, base
import argparse
import numpy as np
import pandas as pd
import tensorflow as tf
tf.config.run_functions_eagerly(True)
physical_devices = tf.config.list_physical_devices('GPU') 
tf.config.experimental.set_memory_growth(physical_devices[0], True)
tf.config.experimental.set_memory_growth(physical_devices[1], True)

parser = argparse.ArgumentParser(description='Parametric t-SNE with Data Streams experiment generator.')
parser.add_argument('--num_instances', type=int, 
                    help='Number of stream instances')
parser.add_argument('--num_features', type=int,
                    help='Number of numerical features')
parser.add_argument('--cat_features', type=int,
                    help='Number of categorical features')
parser.add_argument('--burnout_window', type=int,
                    help='Burnout window size')
parser.add_argument('--block_size', type=int, default=100,
                    help='Prequential block size')
parser.add_argument('--n_components', type=int, default=2,
                    help='Number of t-SNE components')
parser.add_argument('--n_iter_tsne', type=int, default=10,
                    help='Number of t-SNE components')


args = parser.parse_args()

def matrix_to_river_iterator(X, y=None, classes=None):
    if classes == None:
        classes = ["x","y"] + [chr(97 + i) for i in range(len(X[0])-2)]
    if y is None:
        y = [False for i in range(len(X))]
    dict_list = []
    for instance, y_pred in zip(X,y):
        _instance = (dict(zip(classes,instance)), y_pred)
        dict_list.append(_instance)
    
    return islice(dict_list,0)


def matrix_to_dict(X, n_components):
    feature_names = [str(i) for i in range(n_components)]
    
    dict_list = []
    for instance in X:
        dict_list.append(dict(zip(feature_names,instance)))
    
    return dict_list


def dict_to_highest_class(y):
    highest_classes = []
    for instance in y:
        highest_classes.append(list({k: v for k, v in sorted(instance.items(), key=lambda item: item[1])}.keys())[-1])
    
    return highest_classes


def round_probs(d):
    for key in d.keys():
        d[key] = round(d[key])
    
    return d


def generate_datasets(n_features, n_cat_features, seed=None): # 50/50 pra num/cat
    return {
        "Hyperplane": synth.Hyperplane(seed=seed, n_features=n_features),
        "RandomRBF": synth.RandomRBF(seed_sample=seed, n_features=n_features),
        "RandomRBFDrift": synth.RandomRBFDrift(seed_sample=seed, n_features=n_features),
        "RandomTree": synth.RandomTree(seed_sample=seed, n_num_features=n_features, n_cat_features=n_cat_features)
    }


def prequential(classifier, X, y, num_instances, burnout_window):
    bw_X = X[:burnout_window]
    bw_y = y[:burnout_window]
    classifier.fit(bw_X, bw_y)
    
    metric = metrics.Accuracy()
    
    for i in range(num_instances):
        instance_x = np.array([X[i]])
        instance_y = np.array([y[i]])
        prediction = classifier.predict(instance_x)
        metric = metric.update(y[i], prediction[0])
        
        classifier.fit(instance_x, instance_y)
    
    return metric


def block_prequential(classifier, X, y, num_instances, burnout_window, block_size=100):
    global args
    bw_X = X[:burnout_window]
    bw_y = y[:burnout_window]
    classifier.fit(bw_X, bw_y, n_iter_tsne=args.n_iter_tsne)
    
    metric = metrics.Accuracy()
    
    for i in range(0, num_instances, block_size):
        block_X = X[i:min(num_instances, i+block_size)]
        block_y = y[i:min(num_instances, i+block_size)]
        
        predictions = classifier.predict(block_X)

        for j in range(min(num_instances-i, block_size)):
            metric = metric.update(block_y[j], predictions[j])
        
        classifier.fit(block_X, block_y, batch_size=block_size, n_iter_tsne=args.n_iter_tsne)
    
    return metric


class TSNEClassifier(base.Classifier):
    def __init__(self, classifier, n_components=2, perplexity=30., verbose=0, batch_size=20):
        self.classifier = classifier
        self.tsne = ParametricTSNE(n_components, perplexity, verbose)
        self._n_components = n_components
        self._batch_size = batch_size
        self._x_instances = []
        self._y_instances = []
        
    def fit(self, X, y, batch_size=100, n_iter_tsne=100):
        if batch_size > len(X):
            batch_size = len(X)
            
        self.tsne.fit(X,y,batch_size=batch_size, n_iter=n_iter_tsne)
        X_new = self.tsne.transform(X)
        feature_names = [str(i) for i in range(self._n_components)]
        for instance_x, instance_y in zip(X_new, y):
            self.classifier.learn_one(dict(zip(feature_names,instance_x)), instance_y)
        
        return self
    
    def predict(self, X, y=None):
        X_new = self.tsne.transform(X)
        X_new = matrix_to_dict(X_new, self._n_components)
        if not self.classifier.predict_one:
            return [round_probs(self.classifier.predict_proba_one(instance)) for instance in X_new]
        
        return [self.classifier.predict_one(instance) for instance in X_new]
    
    def predict_proba(self, X):
        X_new = self.tsne.transform(X)
        X_new = matrix_to_dict(X_new, self._n_components)
        return [self.classifier.predict_proba_one(instance) for instance in X_new]
    
    def learn_one(self, x, y=None):
        if len(self._x_instances) < self._batch_size:
            self._x_instances.append(x)
            self._y_instances.append(y)
            return self
        
        result = self.fit(np.array(self._x_instances), np.array(self._y_instances))
        self._x_instances = []
        self._y_instances = []
        return result
    
    def predict_one(self, x, y=None):
        x_list = list(x.values())
        X_new = self.tsne.transform(np.asarray(x_list).reshape(1,len(x_list)))
        X_new = matrix_to_dict(X_new, self._n_components)[0]
        return self.classifier.predict_one(X_new)
    
    def predict_proba_one(self, x, y=None):
        X_new = self.tsne.transform(x.values())
        X_new = matrix_to_dict(X_new, self._n_components)
        return self.classifier.predict_proba_one(X_new)
    
 
 
classifiers = [ensemble.ADWINBaggingClassifier(model=linear_model.LogisticRegression(), n_models=10, seed=None),
                ensemble.AdaBoostClassifier(model=(tree.HoeffdingTreeClassifier(split_criterion='gini', split_confidence=1e-5, grace_period=2000)), n_models=10, seed=None),
                ensemble.AdaptiveRandomForestClassifier(n_models=10, max_features="sqrt", lambda_value=6, metric=metrics.Accuracy(), disable_weighted_vote=False, drift_detector=drift.ADWIN(), warning_detector=drift.ADWIN(), grace_period=50, max_depth=None, split_criterion="info_gain", split_confidence=0.01, tie_threshold=0.05, leaf_prediction="nba", nb_threshold=0, nominal_attributes=None, splitter=None, max_size=32, memory_estimate_period=2000000, seed=None),
                ensemble.BaggingClassifier(model=(preprocessing.StandardScaler() | linear_model.LogisticRegression()), n_models=10, seed=None),
                ensemble.LeveragingBaggingClassifier(model=(preprocessing.StandardScaler() | linear_model.LogisticRegression()), n_models=10, w=6, adwin_delta=0.002, bagging_method="bag", seed=None)]


datasets = generate_datasets(args.num_features, args.cat_features)

print("TRAINING BLOCK PARAMETRIC t-SNE CLASSIFIERS")

results = pd.DataFrame({'Classifier': [], 'Dataset': [], 'Accuracy': []})
row = 0

for classifier in classifiers:
    for name, dataset in datasets.items():
        train_instances = np.asarray(list(dataset.take(args.num_instances)))
        X_train = np.asarray([np.asarray(list(a[0].values())) for a in train_instances])
        y_train = np.asarray([a[1] for a in train_instances])

        acc = block_prequential(TSNEClassifier(classifier, n_components=args.n_components), X_train, y_train, args.num_instances, args.burnout_window, block_size=args.block_size)
        print(classifier.__class__.__name__, name + ": " + str(acc))
        results.loc[row] = [classifier.__class__.__name__, name, acc.get()]
        row+=1


results.to_csv(f"experimento_tsne_prequential_block_i{args.num_instances}_nf{args.num_features}_cf{args.cat_features}_bw{args.burnout_window}_bs{args.block_size}_c{args.n_components}.csv", index=False)





from itertools import islice
from river import drift
from river import synth
from river import ensemble, linear_model
from river import metrics, evaluate, datasets, tree, preprocessing, base
import argparse
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser(description='Parametric t-SNE with Data Streams experiment generator.')
parser.add_argument('--num_instances', type=int, 
                    help='Number of stream instances')
parser.add_argument('--num_features', type=int,
                    help='Number of numerical features')
parser.add_argument('--cat_features', type=int,
                    help='Number of categorical features')
parser.add_argument('--burnout_window', type=int,
                    help='Burnout window size')
parser.add_argument('--block_size', type=int, default=100,
                    help='Prequential block size')


args = parser.parse_args()


def matrix_to_river_iterator(X, y=None, classes=None):
    if classes == None:
        classes = ["x","y"] + [chr(97 + i) for i in range(len(X[0])-2)]
    if y is None:
        y = [False for i in range(len(X))]
    dict_list = []
    for instance, y_pred in zip(X,y):
        _instance = (dict(zip(classes,instance)), y_pred)
        dict_list.append(_instance)
    
    return islice(dict_list,0)


def matrix_to_dict(X):
    classes = ["x","y"]
    
    dict_list = []
    for instance in X:
        dict_list.append(dict(zip(classes,instance)))
    
    return dict_list


def dict_to_highest_class(y):
    highest_classes = []
    for instance in y:
        highest_classes.append(list({k: v for k, v in sorted(instance.items(), key=lambda item: item[1])}.keys())[-1])
    
    return highest_classes


def generate_datasets(n_features, n_cat_features, seed=None): # 50/50 pra num/cat
    return {
        "Hyperplane": synth.Hyperplane(seed=seed, n_features=n_features),
        "RandomRBF": synth.RandomRBF(seed_sample=seed, n_features=n_features),
        "RandomRBFDrift": synth.RandomRBFDrift(seed_sample=seed, n_features=n_features),
        "RandomTree": synth.RandomTree(seed_sample=seed, n_num_features=n_features, n_cat_features=n_cat_features)
    }


def block_prequential(classifier, X, y, num_instances, burnout_window, block_size=100):
    for i in range(burnout_window):
        classifier.learn_one(X[i], y[i])
    
    metric = metrics.Accuracy()
    
    for i in range(0, num_instances, block_size):
        block_X = X[i:min(num_instances, i+block_size)]
        block_y = y[i:min(num_instances, i+block_size)]
        
        predictions = [classifier.predict_one(instance) for instance in block_X]

        for j in range(min(num_instances-i, block_size)):
            metric = metric.update(block_y[j], predictions[j])
        
        for k in range(len(block_X)):
          classifier.learn_one(block_X[k], block_y[k])
    
    return metric
 
 
classifiers = [ensemble.ADWINBaggingClassifier(model=linear_model.LogisticRegression(), n_models=10, seed=None),
                ensemble.AdaBoostClassifier(model=(tree.HoeffdingTreeClassifier(split_criterion='gini', split_confidence=1e-5, grace_period=2000)), n_models=10, seed=None),
                ensemble.AdaptiveRandomForestClassifier(n_models=10, max_features="sqrt", lambda_value=6, metric=metrics.Accuracy(), disable_weighted_vote=False, drift_detector=drift.ADWIN(), warning_detector=drift.ADWIN(), grace_period=50, max_depth=None, split_criterion="info_gain", split_confidence=0.01, tie_threshold=0.05, leaf_prediction="nba", nb_threshold=0, nominal_attributes=None, splitter=None, max_size=32, memory_estimate_period=2000000, seed=None),
                ensemble.BaggingClassifier(model=(preprocessing.StandardScaler() | linear_model.LogisticRegression()), n_models=10, seed=None),
                ensemble.LeveragingBaggingClassifier(model=(preprocessing.StandardScaler() | linear_model.LogisticRegression()), n_models=10, w=6, adwin_delta=0.002, bagging_method="bag", seed=None)]


datasets = generate_datasets(args.num_features, args.cat_features)

print("TRAINING DATA STREAM CLASSIFIERS")

results = pd.DataFrame({'Classifier': [], 'Dataset': [], 'Accuracy': []})
row = 0

for classifier in classifiers:
    for name, dataset in datasets.items():
        train_instances = np.asarray(list(dataset.take(args.num_instances)))
        X_train = np.asarray([a[0] for a in train_instances])
        y_train = np.asarray([a[1] for a in train_instances])

        acc = block_prequential(classifier, X_train, y_train, args.num_instances, args.burnout_window, block_size=args.block_size)
        print(classifier.__class__.__name__, name + ": " + str(acc))
        results.loc[row] = [classifier.__class__.__name__, name, acc.get()]
        row+=1


results.to_csv(f"experimento_stream_prequential_block_i{args.num_instances}_nf{args.num_features}_cf{args.cat_features}_bw{args.burnout_window}_bs{args.block_size}.csv", index=False)




